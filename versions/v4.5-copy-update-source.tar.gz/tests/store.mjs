import assert from 'node:assert/strict';
import {createPlannerStore} from '../src/store.js';
import {PRESETS,clone} from '../src/model.js';
const s=createPlannerStore();let notifications=0;const off=s.subscribe(()=>notifications++);
try{
assert.deepEqual(s.getSnapshot().items,PRESETS[0].items);
const first=s.getSnapshot();s.setFilter('氛围');assert.notEqual(first,s.getSnapshot());assert.equal(first.filter,'全部');
const block=s.addItem('block',0,0,0);assert.equal(s.getSnapshot().selected,block.id);
assert.equal(s.moveItem(block.id,{gx:1,gy:1,gz:1}),true);
const saved=clone(s.getSnapshot().items);assert.equal(s.moveItem(block.id,{gx:-1}),false);assert.deepEqual(s.getSnapshot().items,saved);
s.addItem('block',2,1,1,null,true);assert.equal(s.moveItem(block.id,{gx:2}),false);
s.duplicate(block.id);assert.equal(s.getSnapshot().items.length,9);
s.remove(block.id);assert.equal(s.getSnapshot().items.length,8);
for(let i=0;i<4;i++){s.setPreset(i);assert.deepEqual(s.getSnapshot().items,PRESETS[i].items);assert.equal(s.getSnapshot().night,i===3);assert.equal(s.getSnapshot().dirty,false);}
s.setExhibition(1);s.toggleState('v1');assert.equal(s.getSnapshot().items.find(a=>a.id==='v1').state,1);s.setExhibition(0);
s.patchItem('d',{intensity:85,temperature:4000,color:'#ed8e40'});const d=s.exportData();assert.equal(d.version,'grid48-1');assert.equal(d.grid.unit_mm,48);assert.equal(d.modules.find(a=>a.id==='d').intensity,85);assert.deepEqual(d.modules[0].position_cells,[3,27,0]);
s.togglePlay();assert.equal(s.getSnapshot().playing,true);s.moveItem('a',{gx:4});assert.equal(s.getSnapshot().playing,false);
s.toggleGrid();assert.equal(s.getSnapshot().showDims,false);assert.ok(notifications>20);
s.setExhibition(1);assert.equal(s.getSnapshot().transition.retained,3);assert.equal(s.getSnapshot().transition.nodes,6);assert.equal(s.exportData().exhibition,'层架陈列');
s.setExhibition(2);assert.equal(s.getSnapshot().transition.moved,3);s.toggleState('r1');assert.equal(s.getSnapshot().items.find(a=>a.id==='r1').state,1);assert.equal(s.exportData().modules.find(a=>a.id==='r1').assembly.nodes,4);
s.setExhibition(3);assert.equal(s.getSnapshot().exhibition,3);s.setPreset(1);s.setPreset(0);assert.equal(s.getSnapshot().exhibition,3);
console.log('React store: immutable snapshots, add/duplicate/remove, movement/collision, presets, states, export and autoplay passed.');
}finally{off();s.destroy();}
